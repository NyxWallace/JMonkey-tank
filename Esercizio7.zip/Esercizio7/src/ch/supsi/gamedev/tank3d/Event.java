package ch.supsi.gamedev.tank3d;

public class Event {
	
	private final String id;

	public Event(String id) {
		this.id = id;
	}

	public String id() {
		return id;
	}
}
